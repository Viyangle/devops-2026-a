# E7 A 提交包：谢浩天 241250033

2026-11-06，A09 组。服务器端实验与 E7 CI 均使用 60.204.240.40（devops）。

- [个人实验报告](source/REPORT-241250033.md)
- [验收表](source/E7验收记录-241250033.csv)
- [个人贡献](source/CONTRIBUTIONS.md)
- [源码与复跑](source/README.md)
- [提交版本与 CI 索引](submission.json)
- [小组仓库检查日志](group-check.txt)

判定测试8项、最终服务测试17项、门禁8项通过。相同 PR 的失败、实际拒绝合并、修复恢复与合并记录齐全。

source/ 保存报告提交 bec89b3 的完整受跟踪文件；实际运行源码 d2cbe21，之后补充文档和证据。work/ 包含全部服务器本地运行与四次下载的 CI artifact，保留构建失败及重跑记录。SHA256SUMS 列出各文件哈希。

GitHub 后续提交、推送和合并已按用户要求暂停。此前完成的远端状态见 submission.json；小组 PR #47 仍为 OPEN。
