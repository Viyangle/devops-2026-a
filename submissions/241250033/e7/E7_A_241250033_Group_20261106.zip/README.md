# 谢浩天 241250033：A 组 E7 最终集成包

仓库 https://github.com/Viyangle/devops-2026-a ，代码通过 PR #3 合入 main。
运行源码 4e81e9c2713e220a25bcab294b58ad7a5673a899；合并提交 4f87c2452f3caaa51793f24a7e51a9da23d00ebe。

- submission/：个人报告、已填写模板、验收表、贡献记录、两阶段关键证据及原独立实验完整包。
- source-4e81e9c.tar.gz：GitHub API 下载的本次恢复 CI 源码快照。
- work/ci-normal、ci-rejection、ci-recovery：完整下载 artifact、精确 run/head SHA 和实际合并记录。
- work/setup-failure：首次 Docker 配置目录权限问题的失败记录。
- work/dispatch-validation.json：同机隔离调度器的外层超时清理和锁等待实测。
- SHA256SUMS：本包每个文件的 SHA-256；外层 ZIP 哈希保存在仓库 publication.json 中。

全部实验检查在 60.204.240.40 执行，GitHub 托管 runner 负责传输与归档。恢复 CI 的 oracle 9 项、服务 17 项、门禁 8 项全部通过。
